// Protocol reference: guoapp 0e60928514c31a96ade9b31866948f15da5ca2a6,
// provider_hongguo_{app,sign,native_media,playback}.go. No account credentials.
const _hg_appBaseURL = "https://api5-normal-sinfonlineb.fqnovel.com";
const _hg_appUserAgent = "com.phoenix.read/73532 (Linux; U; Android 16; zh_CN; 25053RT47C; Build/BP2A.250605.031.A3; Cronet/TTNetVersion:04657795 2026-01-23 QuicVersion:c67e9834 2025-09-08)";
const _hg_appDevice = { device_id: _hg_newDeviceId(), iid: _hg_newDeviceId() };

function _hg_newDeviceId() {
  let id = String(1 + Math.floor(Math.random() * 8));
  for (let i = 0; i < 18; i += 1) id += String(Math.floor(Math.random() * 10));
  return id;
}

function _hg_queryEncode(value) {
  return encodeURIComponent(String(value)).replace(/[!'()*]/g, (ch) =>
    "%" + ch.charCodeAt(0).toString(16).toUpperCase()).replace(/%20/g, "+");
}

function _hg_hex(bytes) {
  return Array.from(bytes, (value) => (value < 16 ? "0" : "") + value.toString(16)).join("");
}

function _hg_md5(value) {
  if (!globalThis.Host || !Host.crypto || typeof Host.crypto.md5 !== "function") {
    _hg_throw("UNSUPPORTED", "当前宿主缺少红果取流所需的 MD5 接口，请更新 AngelLive", { stage: "appSigning" });
  }
  const digest = String(Host.crypto.md5(value)).toLowerCase();
  if (!/^[0-9a-f]{32}$/.test(digest)) {
    _hg_throw("UPSTREAM", "宿主返回了无效的请求摘要", { stage: "appSigning" });
  }
  return digest;
}

// Playback request timestamp fields observed in drpys' signedVideoRequest.
// Encode a uint32 directly so JSCore needs neither Buffer nor btoa.
function _hg_base64Word(value, littleEndian) {
  const word = value >>> 0;
  const bytes = [word >>> 24, (word >>> 16) & 255, (word >>> 8) & 255, word & 255];
  if (littleEndian) bytes.reverse();
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  return alphabet[bytes[0] >>> 2] + alphabet[((bytes[0] & 3) << 4) | (bytes[1] >>> 4)]
    + alphabet[((bytes[1] & 15) << 2) | (bytes[2] >>> 6)] + alphabet[bytes[2] & 63]
    + alphabet[bytes[3] >>> 2] + alphabet[(bytes[3] & 3) << 4] + "==";
}

function _hg_signAppRequest(query, body, ticket) {
  const bodyHash = _hg_md5(body);
  const queryHash = _hg_md5(query);
  const seconds = Math.floor(ticket / 1000) >>> 0;
  const bytes = [];
  for (const hash of [queryHash, bodyHash]) {
    for (let i = 0; i < 8; i += 2) bytes.push(parseInt(hash.slice(i, i + 2), 16));
  }
  bytes.push(0, 0, 0, 0, 0, 6, 11, 28,
    seconds >>> 24, (seconds >>> 16) & 255, (seconds >>> 8) & 255, seconds & 255);
  // Public protocol mixing constants, not an account or API signing secret.
  const mask = [68, 185, 185, 217, 164, 174, 249, 252, 164, 147, 170, 117, 124, 163, 194, 196, 164, 150, 147, 143];
  for (let i = 0; i < bytes.length; i += 1) bytes[i] ^= mask[i];
  for (let i = 0; i < bytes.length; i += 1) {
    const mixed = (((bytes[i] << 4) | (bytes[i] >>> 4)) & 255) ^ bytes[(i + 1) % bytes.length];
    let reversed = 0;
    for (let bit = 0; bit < 8; bit += 1) reversed = (reversed << 1) | ((mixed >>> bit) & 1);
    bytes[i] = reversed ^ 255 ^ bytes.length;
  }
  return {
    "X-SS-STUB": bodyHash.toUpperCase(),
    "X-Khronos": String(seconds),
    "X-SS-Req-Ticket": String(ticket),
    "X-Gorgon": "8404401c0000" + _hg_hex(bytes),
    "X-Ladon": _hg_base64Word(seconds, false),
    "X-Argus": _hg_base64Word(seconds, true)
  };
}

// 官方 VideoContentType: ShortSeriesPlay=1 (smali VideoContentType.java 实证)。
// caller_scene 官方播放主线取值 (baksmali 实证, 见 docs/research)：
// 选集进入 album_video_list / 自动连播 episode_end_outer / 离线 download。
const _HG_CALLER_SCENE_PLAYBACK = "album_video_list";

async function _hg_appPlaybackRequest(vid, callerScene) {
  const scene = _hg_str(callerScene).trim() || _HG_CALLER_SCENE_PLAYBACK;
  const body = JSON.stringify({
    video_id: vid, content_type: 1,
    biz_param: {
      caller_scene: scene,
      need_all_video_definition: true, video_platform: 3
    }
  });
  let response;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const ticket = Date.now();
    const params = Object.assign({
      aid: "8662", app_name: "novelread", version_code: "73532", version_name: "7.3.5.32",
      manifest_version_code: "73532", update_version_code: "73532", channel: "update_64",
      device_platform: "android", os: "android", ssmix: "a", device_type: "25053RT47C",
      device_brand: "Redmi", language: "zh", os_api: "36", os_version: "16",
      resolution: "1280*2772", dpi: "520", ac: "wifi", _rticket: String(ticket)
    }, _hg_appDevice);
    const query = Object.keys(params).sort().map((key) => _hg_queryEncode(key) + "=" + _hg_queryEncode(params[key])).join("&");
    const headers = Object.assign({
      "User-Agent": _hg_appUserAgent, "Accept": "application/json",
      "Content-Type": "application/json; charset=utf-8", "X-XS-From-Web": "0", "Sdk-Version": "2"
    }, _hg_signAppRequest(query, body, ticket));
    try {
      const candidate = await Host.http.request({
        url: _hg_appBaseURL + "/novel/player/video_model/v1/?" + query,
        method: "POST", headers, body, timeout: 12
      });
      const candidateStatus = Number(candidate && (candidate.status !== undefined ? candidate.status : candidate.statusCode));
      // 服务端会间歇性返回 HTTP 200 空响应；换票据重签一次，命中正常节点即恢复。
      const candidateBody = _hg_str(candidate && candidate.bodyText).trim();
      if (attempt === 0 && candidateStatus < 400 && !candidateBody) continue;
      response = candidate;
      break;
    } catch (error) {
      if (attempt === 0 && _hg_isNetworkError(error)) continue;
      // Do not copy native request URLs, response bodies or signatures into errors.
      _hg_throw(_hg_isNetworkError(error) ? _hg_errorDetails(error).code : "UPSTREAM",
        "红果官方取流请求失败，请稍后重试", { stage: "appPlayback", vid });
    }
  }
  const status = Number(response && (response.status !== undefined ? response.status : response.statusCode));
  if (status >= 400) {
    _hg_throw(status === 404 ? "NOT_FOUND" : "UPSTREAM", "红果官方取流接口暂不可用", { stage: "appPlayback", status, vid });
  }
  const raw = _hg_str(response && response.bodyText).trim();
  let result;
  try {
    if (!raw || raw.length > 2 * 1024 * 1024) throw new Error();
    result = JSON.parse(raw);
  } catch (_) {
    _hg_throw("UPSTREAM", "红果官方取流接口未返回有效数据", { stage: "appPlayback", vid });
  }
  const code = result && (result.code !== undefined ? result.code : result.status_code);
  if (code !== undefined && code !== null && String(code) !== "0") {
    _hg_throw("UPSTREAM", "红果官方取流接口暂不可用", { stage: "appPlayback", vid });
  }
  let model = result && result.data && result.data.video_model;
  if (typeof model === "string") {
    try { model = JSON.parse(model); } catch (_) { model = null; }
  }
  if (!model || typeof model !== "object" || Array.isArray(model)) {
    _hg_throw("UPSTREAM", "红果官方播放信息格式异常", { stage: "appPlayback", vid });
  }
  return model;
}

// JSCore's Host.crypto.base64Decode only returns UTF-8 strings; spade_a is binary.
function _hg_base64Bytes(value) {
  const text = _hg_str(value).trim();
  if (!text || !/^[A-Za-z0-9+/]*={0,2}$/.test(text)) return null;
  const raw = text.replace(/=+$/, "");
  if (raw.length % 4 === 1 || (raw.length !== text.length && text.length % 4 !== 0)) return null;
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const bytes = [];
  let bits = 0;
  let buffer = 0;
  for (let i = 0; i < raw.length; i += 1) {
    buffer = (buffer << 6) | alphabet.indexOf(raw[i]);
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      bytes.push((buffer >>> bits) & 255);
    }
  }
  if (bits && (buffer & ((1 << bits) - 1))) return null;
  return bytes;
}

function _hg_contentKey(spade) {
  const fail = () => _hg_throw("UPSTREAM", "红果媒体密钥不可用，请重试或更新插件", { stage: "contentKey" });
  if (typeof spade !== "string" || spade.length > 1024) return fail();
  const bytes = _hg_base64Bytes(spade);
  if (!bytes || bytes.length < 3) return fail();
  const tagLength = (bytes[0] ^ bytes[1] ^ bytes[2]) - 48;
  const contentLength = bytes.length - tagLength - 1;
  if (tagLength < 1 || contentLength < 33 || contentLength >= bytes.length) return fail();
  const seed = bytes[contentLength - 1] ^ bytes[contentLength];
  const tag = bytes.slice(contentLength + 1).map((byte) => String.fromCharCode(byte ^ seed)).join("");
  if (tag === "app_v2" || tag === "web_v2") return fail();
  const previous = [250, 85];
  let decoded = "";
  for (let i = 0; i < contentLength; i += 1) {
    let popcount = 0;
    for (let n = i; n; n >>>= 1) popcount += n & 1;
    const byte = bytes[i + 1];
    decoded += String.fromCharCode(((previous[i % 2] ^ byte) - 21 - popcount) & 255);
    previous[i % 2] = byte;
  }
  const padding = /^[0-9a-z]$/i.test(decoded[0]) ? parseInt(decoded[0], 36) : NaN;
  const key = decoded.slice(1, 33);
  if (contentLength - padding - 1 !== 32 || !/^[0-9a-f]{32}$/i.test(key)) return fail();
  return key.toLowerCase();
}

function _hg_mediaURLs(info) {
  const urls = [];
  function add(value) {
    if (Array.isArray(value)) { value.forEach(add); return; }
    if (typeof value !== "string" || value.length > 8192) return;
    let url = value.trim();
    if (!/^https?:\/\//i.test(url) && !url.startsWith("//")) {
      const bytes = _hg_base64Bytes(url);
      if (!bytes) return;
      url = bytes.map((byte) => String.fromCharCode(byte)).join("").trim();
    }
    if (url.startsWith("//")) url = "https:" + url;
    if (/^https?:\/\/[^\s/?#]+(?:[/?#]|$)/i.test(url) && !urls.includes(url)) urls.push(url);
  }
  for (const field of ["main_url", "backup_url", "backup_url_1", "backup_url_2", "backup_urls", "url_list"]) add(info && info[field]);
  return urls;
}

function _hg_selectAppMedia(model) {
  const list = model && model.video_list;
  const variants = Array.isArray(list) ? list : list && typeof list === "object" ? Object.keys(list).sort().map((key) => list[key]) : [];
  const choices = [];
  let keyError;
  for (const variant of variants) {
    if (!variant || typeof variant !== "object") continue;
    const meta = variant.video_meta || {};
    const codec = _hg_str(meta.codec_type).toLowerCase();
    if (codec === "bytevc2" || /bytevc2/i.test(_hg_str(variant.gear_des_key))) continue;
    const urls = _hg_mediaURLs(variant);
    if (!urls.length) continue;
    const encryption = variant.encrypt_info || {};
    const method = _hg_str(encryption.encryption_method).trim().toLowerCase();
    const encrypted = !!encryption.spade_a || encryption.encrypt === true || String(encryption.encrypt) === "1" || !!method;
    const media = {
      url: urls[0], source: "app", userAgent: _hg_appUserAgent,
      headers: { "Referer": "https://novel.snssdk.com/" }
    };
    if (encrypted) {
      try {
        if (method && method !== "cenc-aes-ctr") {
          _hg_throw("UNSUPPORTED", "红果返回了暂不支持的加密方式", { stage: "contentKey" });
        }
        media.decryption = { method: "cenc", key: _hg_contentKey(encryption.spade_a) };
      } catch (error) { keyError = error; continue; }
    }
    const definition = _hg_str(meta.definition).match(/\d+/);
    const width = Math.max(0, _hg_int(meta.vwidth, 0));
    const height = Math.max(0, _hg_int(meta.vheight, 0));
    const quality = definition ? Number(definition[0]) : width && height ? Math.min(width, height) : width || height;
    choices.push({ media, score: quality * 10 + (codec === "h264" || codec === "avc1" ? 1 : 0) });
  }
  choices.sort((a, b) => b.score - a.score);
  if (choices.length) return choices[0].media;
  if (keyError) throw keyError;
  _hg_throw("NOT_FOUND", "红果官方接口没有返回兼容的播放地址", { stage: "appPlayback" });
}

// App 详情接口返回完整分集目录；官网 SSR 详情页的 vid_list 可能只含预览集。
// video_id 使用官网首集 VID，避免把 series_id 当成单集视频 ID。
function _hg_collectEpisodeIds(root) {
  const listKeys = new Set([
    "video_list", "episode_list", "episodes", "chapter_list",
    "video_data", "item_list", "aweme_list", "episode_data"
  ]);
  const idKeys = ["video_id", "vid", "videoId", "item_id"];
  const found = [];
  const seen = new Set();
  const visited = new Set();

  function add(value) {
    const id = _hg_str(value).trim();
    if (_hg_isNumericId(id) && !seen.has(id)) {
      seen.add(id);
      found.push(id);
    }
  }
  function visit(value, depth) {
    if (!value || depth > 12 || typeof value !== "object" || visited.has(value)) return;
    visited.add(value);
    if (Array.isArray(value)) {
      value.forEach((item) => visit(item, depth + 1));
      return;
    }
    for (const key of Object.keys(value)) {
      const child = value[key];
      if (listKeys.has(key) && Array.isArray(child)) {
        for (const item of child) {
          if (typeof item === "string" || typeof item === "number") {
            add(item);
          } else if (item && typeof item === "object") {
            let id = "";
            for (const idKey of idKeys) {
              if (item[idKey] !== undefined && item[idKey] !== null) {
                id = item[idKey];
                break;
              }
            }
            add(id);
            visit(item, depth + 1);
          }
        }
      }
      visit(child, depth + 1);
    }
  }
  visit(root, 0);
  return found;
}

async function _hg_fetchAppEpisodeIds(seriesId, firstVid) {
  const seedVid = _hg_str(firstVid).trim();
  if (!_hg_isNumericId(seriesId) || !_hg_isNumericId(seedVid)) return [];

  const ticket = Date.now();
  const params = Object.assign({
    aid: "8662", app_name: "novelread", version_code: "73532", version_name: "7.3.5.32",
    manifest_version_code: "73532", update_version_code: "73532", channel: "update_64",
    device_platform: "android", os: "android", ssmix: "a", device_type: "25053RT47C",
    device_brand: "Redmi", language: "zh", os_api: "36", os_version: "16",
    resolution: "1280*2772", dpi: "520", ac: "wifi", _rticket: String(ticket),
    video_id: seedVid, content_type: "1"
  }, _hg_appDevice);
  const query = Object.keys(params).sort()
    .map((key) => _hg_queryEncode(key) + "=" + _hg_queryEncode(params[key])).join("&");
  const headers = Object.assign({
    "User-Agent": _hg_appUserAgent,
    "Accept": "application/json",
    "X-XS-From-Web": "0",
    "Sdk-Version": "2"
  }, _hg_signAppRequest(query, "", ticket));

  let response;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      response = await Host.http.request({
        url: _hg_appBaseURL + "/novel/player/video_detail/v1/?" + query,
        method: "GET", headers, timeout: 12
      });
      const status = Number(response && (response.status !== undefined ? response.status : response.statusCode));
      const raw = _hg_str(response && response.bodyText).trim();
      if (attempt === 0 && status < 400 && !raw) continue;
      if (status >= 400 || !raw || raw.length > 2 * 1024 * 1024) return [];
      let result;
      try { result = JSON.parse(raw); } catch (_) { return []; }
      const code = result && (result.code !== undefined ? result.code : result.status_code);
      if (code !== undefined && code !== null && String(code) !== "0") return [];
      const ids = _hg_collectEpisodeIds(result);
      // 只接受包含请求首集的目录，避免把相关推荐/其他剧的 VID 混进选集。
      return ids.includes(seedVid) ? ids : [];
    } catch (error) {
      if (attempt === 0 && _hg_isNetworkError(error)) continue;
      return [];
    }
  }
  return [];
}

async function _hg_fetchAppEpisodeMedia(vid, callerScene) {
  return _hg_selectAppMedia(await _hg_appPlaybackRequest(vid, callerScene));
}
