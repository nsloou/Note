const _hg_liveType = "18";
const _hg_baseURL = "https://hongguoduanju.com";
const _hg_webUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36";
const _hg_defaultUserName = "红果短剧";
const _hg_categoryCache = new Map();
const _hg_categoryFreshMs = 60 * 1000;
const _hg_categoryFallbackMs = 15 * 60 * 1000;

// 分类与二级题材取自红果短剧网页版导航（hongguoduanju.com），路由仅允许小写字母/数字/连字符。
const _hg_categories = [
  {
    route: "real-drama",
    title: "真人剧",
    subs: [
      ["romance", "爱情"], ["period", "年代"], ["comeback", "逆袭"], ["legend", "传奇"],
      ["growth", "成长"], ["family", "家庭"], ["clan", "家族"], ["cute-kids", "萌宝"],
      ["suspense", "悬疑"], ["thriller", "惊悚"], ["horror", "恐怖"], ["supernatural", "志怪"],
      ["costume", "古装"], ["fantasy", "玄幻"], ["wonder", "奇幻"], ["urban", "都市"],
      ["youth", "青春"], ["comedy", "喜剧"], ["sci-fi", "科幻"], ["disaster", "灾难"],
      ["action-adventure", "动作冒险"], ["war", "战争"], ["variety", "综艺"], ["drama", "剧情"]
    ]
  },
  {
    route: "comic-drama",
    title: "漫剧",
    subs: [
      ["adventure", "冒险"], ["apocalypse", "末世"], ["creative", "脑洞"], ["drama", "剧情"],
      ["fantasy", "玄幻"], ["sci-fi", "科幻"], ["wealthy-family", "豪门"], ["wonder", "奇幻"]
    ]
  },
  {
    route: "ai-drama",
    title: "AI剧",
    subs: [
      ["adventure", "冒险"], ["apocalypse", "末世"], ["creative", "脑洞"], ["drama", "剧情"],
      ["fantasy", "玄幻"], ["sci-fi", "科幻"], ["wealthy-family", "豪门"], ["wonder", "奇幻"]
    ]
  },
  {
    route: "comic",
    title: "漫画",
    subs: []
  }
];

function _hg_makeError(code, message, context) {
  if (globalThis.Host && typeof Host.makeError === "function") {
    return Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  return new Error(`LP_PLUGIN_ERROR:${JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  })}`);
}

function _hg_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  throw new Error(`LP_PLUGIN_ERROR:${JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  })}`);
}

function _hg_str(value) {
  return value === undefined || value === null ? "" : String(value);
}

function _hg_int(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.floor(number) : fallback;
}

function _hg_isNumericId(value) {
  const text = _hg_str(value).trim();
  return /^\d{1,32}$/.test(text);
}

function _hg_isValidRoute(value) {
  return /^[a-z0-9-]+(?:\/[a-z0-9-]+)*$/.test(_hg_str(value).trim());
}

function _hg_httpsURL(value) {
  const url = _hg_str(value).trim();
  if (url.startsWith("//")) return "https:" + url;
  if (url.startsWith("http://")) return "https://" + url.slice(7);
  return url;
}

function _hg_errorDetails(error) {
  if (error && typeof error.code === "string") return error;
  const message = String(error && error.message ? error.message : error);
  const marker = "LP_PLUGIN_ERROR:";
  const start = message.indexOf(marker);
  if (start >= 0) {
    try {
      return JSON.parse(message.slice(start + marker.length));
    } catch (_) {}
  }
  return {};
}

function _hg_isNetworkError(error) {
  const code = _hg_errorDetails(error).code;
  return code === "TIMEOUT" || code === "NETWORK";
}

async function _hg_request(url) {
  let response;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      response = await Host.http.request({
        url,
        method: "GET",
        headers: {
          "User-Agent": _hg_webUserAgent,
          "Referer": _hg_baseURL + "/"
        },
        timeout: 12
      });
      break;
    } catch (error) {
      if (!_hg_isNetworkError(error)) throw error;
      if (attempt === 0) continue;
      const details = _hg_errorDetails(error);
      _hg_throw(details.code, "红果官网连接失败，重试后仍无法访问，请检查网络或代理后再试", Object.assign({}, details.context, {
        attempts: "2"
      }));
    }
  }
  const status = Number(response && (response.status !== undefined ? response.status : response.statusCode));
  if (status === 404) {
    _hg_throw("NOT_FOUND", "该剧集未向网页端开放或已下架，请在红果官方 App 中查看", { status });
  }
  if (status >= 400) {
    _hg_throw("UPSTREAM", "红果页面暂时无法访问，请稍后重试", { status });
  }
  return response;
}

// 网页版各页面把数据内嵌在 window._ROUTER_DATA = {...} 的 JSON 里；
// 用括号配对扫描截取完整 JSON，避免整页 JSON.parse。
function _hg_extractRouterData(html, context) {
  const text = String(html || "");
  const marker = text.match(/(?:window\.)?_ROUTER_DATA\s*=\s*/);
  if (!marker) {
    _hg_throw("UPSTREAM", "红果页面缺少路由数据，页面结构可能已变化", Object.assign({ reason: "no _ROUTER_DATA" }, context || {}));
  }
  const start = marker.index + marker[0].length;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < text.length; index += 1) {
    const ch = text.charAt(index);
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === "\"") inString = false;
      continue;
    }
    if (ch === "\"") inString = true;
    else if (ch === "{") depth += 1;
    else if (ch === "}") {
      depth -= 1;
      if (depth === 0) {
        try {
          return JSON.parse(text.slice(start, index + 1));
        } catch (error) {
          _hg_throw("UPSTREAM", "红果路由数据解析失败", Object.assign({
            reason: String(error && error.message ? error.message : error)
          }, context || {}));
        }
      }
    }
  }
  _hg_throw("UPSTREAM", "红果路由数据不完整", Object.assign({ reason: "unbalanced braces" }, context || {}));
}

// loaderData 的键名随路由变化（如 player_(series_id)/(vid)/page），按数据特征定位页面数据。
function _hg_loaderPage(routerData, predicate) {
  const loader = routerData && routerData.loaderData;
  if (!loader || typeof loader !== "object") return null;
  const keys = Object.keys(loader);
  for (const key of keys) {
    if (!/_page|\$$|\(/.test(key)) continue;
    const value = loader[key];
    if (value && typeof value === "object" && !Array.isArray(value) && predicate(value)) return value;
  }
  for (const key of keys) {
    const value = loader[key];
    if (value && typeof value === "object" && !Array.isArray(value) && predicate(value)) return value;
  }
  return null;
}

function _hg_dramaToRoom(item, categoryTitle) {
  const data = item && item.video_data && typeof item.video_data === "object" ? item.video_data : item;
  const seriesId = _hg_str(data && data.series_id).trim();
  if (!_hg_isNumericId(seriesId)) return null;
  const cover = _hg_httpsURL(data && data.series_cover);
  const count = _hg_str(data && data.episode_cnt).trim();
  const episodeText = _hg_str(data && data.episode_right_text).trim() || (count ? `共${count}集` : "");
  return {
    userName: _hg_str(categoryTitle).trim() || _hg_defaultUserName,
    roomTitle: _hg_str(data && (data.series_name || data.series_title) || seriesId),
    roomCover: cover,
    userHeadImg: cover,
    liveType: _hg_liveType,
    liveState: "2",
    userId: seriesId,
    roomId: seriesId,
    liveWatchedCount: episodeText
  };
}

function _hg_requireSeriesId(payload) {
  const roomId = _hg_str(payload && payload.roomId).trim();
  if (!_hg_isNumericId(roomId)) {
    _hg_throw("INVALID_ARGS", "a numeric roomId (红果 series_id) is required", { field: "roomId" });
  }
  return roomId;
}

async function _hg_fetchCategoryPage(route, page) {
  const cacheKey = route + ":" + page;
  const cached = _hg_categoryCache.get(cacheKey);
  if (cached && Date.now() - cached.time < _hg_categoryFreshMs) return cached.value;
  const pageURL = page >= 2
    ? `${_hg_baseURL}/category/${route}?page=${encodeURIComponent(String(page))}`
    : `${_hg_baseURL}/category/${route}`;
  let response;
  try {
    response = await _hg_request(pageURL);
  } catch (error) {
    if (cached && _hg_isNetworkError(error) && Date.now() - cached.time < _hg_categoryFallbackMs) {
      return cached.value;
    }
    throw error;
  }
  const routerData = _hg_extractRouterData(response && response.bodyText, { route, page });
  const pageData = _hg_loaderPage(routerData, (value) => Array.isArray(value.recommendList));
  if (!pageData || pageData.isSuccess === false) {
    _hg_throw("UPSTREAM", "红果分类数据不可用，可能是页面结构或访问权限变化", { route, page });
  }
  const items = Array.isArray(pageData.recommendList) ? pageData.recommendList : [];
  const value = {
    rooms: items.map((item) => _hg_dramaToRoom(item, _hg_routeTitle(route))).filter((room) => !!room),
    pagination: pageData.pagination && typeof pageData.pagination === "object" ? pageData.pagination : {}
  };
  _hg_categoryCache.delete(cacheKey);
  _hg_categoryCache.set(cacheKey, { time: Date.now(), value });
  if (_hg_categoryCache.size > 16) _hg_categoryCache.delete(_hg_categoryCache.keys().next().value);
  return value;
}

function _hg_routeTitle(route) {
  const normalized = _hg_str(route).trim();
  for (const category of _hg_categories) {
    if (normalized === category.route || normalized.startsWith(category.route + "/")) {
      const sub = category.subs.find((pair) => normalized === category.route + "/" + pair[0]);
      return sub ? `${sub[1]}·${category.title}` : category.title;
    }
  }
  return _hg_defaultUserName;
}

async function _hg_fetchSeriesDetail(seriesId) {
  const response = await _hg_request(`${_hg_baseURL}/detail?series_id=${encodeURIComponent(seriesId)}`);
  const routerData = _hg_extractRouterData(response && response.bodyText, { seriesId });
  const pageData = _hg_loaderPage(routerData, (value) => value.seriesDetail);
  const detail = pageData && pageData.seriesDetail;
  if (!detail || typeof detail !== "object") {
    _hg_throw("NOT_FOUND", "未找到该剧集详情，剧集可能已下架", { seriesId });
  }
  const vids = (Array.isArray(detail.vid_list) ? detail.vid_list : [])
    .map((vid) => _hg_str(vid).trim())
    .filter((vid) => _hg_isNumericId(vid));
  const count = _hg_str(detail.episode_cnt).trim();
  // 此限制仅适用于官网网页回退；官方 App 当前集取流成功后提供完整分集目录，其余集按需验证。
  const rawAccessibleCount = _hg_str(detail.accessible_episode_cnt).trim();
  const accessibleCount = /^\d+$/.test(rawAccessibleCount)
    ? Math.min(Number(rawAccessibleCount), vids.length)
    : null;
  return {
    seriesId,
    name: _hg_str(detail.series_name || detail.series_title || seriesId),
    cover: _hg_httpsURL(detail.series_cover),
    intro: _hg_str(detail.series_intro).trim(),
    episodeText: _hg_str(detail.episode_right_text).trim() || (count ? `共${count}集` : ""),
    vids,
    accessibleCount
  };
}

function _hg_firstMediaURL(info) {
  return _hg_mediaURLs(info)[0] || "";
}

// 播放页公开直链兜底。红果网页版把 SEO 直链以 publicVideoSeo 下发
// （available 且 seriesId/itemId 与所请求剧集一致时可用），地址形如
// /video/public/<vid>/360p.mp4——单段 vid 路径，与官方播放器打包代码一致。
function _hg_publicMediaURL(pageData, seriesId, vid) {
  const seo = pageData && pageData.publicVideoSeo;
  if (!seo || typeof seo !== "object" || !seo.available) return "";
  if (_hg_str(seo.seriesId).trim() !== seriesId) return "";
  if (_hg_str(seo.itemId).trim() !== vid) return "";
  return `${_hg_baseURL}/video/public/${encodeURIComponent(vid)}/360p.mp4`;
}

async function _hg_fetchWebEpisodeMedia(seriesId, vid, allowRetry) {
  const pageURL = `${_hg_baseURL}/player/${encodeURIComponent(seriesId)}/${encodeURIComponent(vid)}`;
  const response = await _hg_request(pageURL);
  const routerData = _hg_extractRouterData(response && response.bodyText, { seriesId, vid });
  const pageData = _hg_loaderPage(routerData, (value) => value.video_player_info || value.publicVideoSeo);
  if (!pageData || pageData.isSuccess === false) {
    _hg_throw("UPSTREAM", "红果播放页数据不可用，可能是页面结构或访问权限变化", { seriesId, vid });
  }
  const pageVid = _hg_str(pageData.vid).trim();
  const pageSeriesId = _hg_str(pageData.series_id).trim();
  const identityMismatch = (pageVid && pageVid !== vid) || (pageSeriesId && pageSeriesId !== seriesId);
  // 无 cookie 首访会被 302 到"pc_locked"首集预览页；宿主在该次飞行中已吸收
  // ttwid，重试一次即携带 cookie 命中本集正式页。
  if (identityMismatch && allowRetry !== false) {
    return await _hg_fetchWebEpisodeMedia(seriesId, vid, false);
  }
  if (identityMismatch) {
    _hg_throw("NOT_FOUND", "红果未返回所请求的剧集，可能仅允许在应用内观看该集", { seriesId, vid });
  }
  // 首选完整信息（多清晰度/多编码）；缺失或未给地址时退回公开 360p 直链。
  if (pageData.video_player_info) {
    const url = _hg_firstMediaURL(pageData.video_player_info);
    if (url) {
      return { url, source: "web", userAgent: _hg_webUserAgent, headers: { "Referer": _hg_baseURL + "/" } };
    }
  }
  const publicURL = _hg_publicMediaURL(pageData, seriesId, vid);
  if (publicURL) {
    return { url: publicURL, source: "web-public", userAgent: _hg_webUserAgent, headers: { "Referer": _hg_baseURL + "/" } };
  }
  _hg_throw("NOT_FOUND", "该集未提供公开播放地址，可能需要登录或已下架", { seriesId, vid });
}

async function _hg_requestJSON(path, bodyObject) {
  let response;
  try {
    response = await Host.http.request({
      url: _hg_baseURL + path,
      method: bodyObject ? "POST" : "GET",
      headers: {
        "User-Agent": _hg_webUserAgent,
        "Referer": _hg_baseURL + "/",
        "Content-Type": "application/json"
      },
      body: bodyObject ? JSON.stringify(bodyObject) : undefined,
      timeout: 12
    });
  } catch (error) {
    const details = _hg_errorDetails(error);
    _hg_throw(details.code || "NETWORK", "红果官网接口连接失败，请检查网络或代理后再试", Object.assign({}, details.context, { path }));
  }
  const status = Number(response && (response.status !== undefined ? response.status : response.statusCode));
  if (status >= 400) {
    _hg_throw(status === 404 ? "NOT_FOUND" : status === 403 ? "UNAVAILABLE" : "UPSTREAM", "红果官网接口暂时不可用，请稍后重试", { path, status });
  }
  let parsed;
  try {
    parsed = JSON.parse(response && response.bodyText);
  } catch (error) {
    _hg_throw("UPSTREAM", "红果官网接口返回了无法解析的数据", { path });
  }
  return parsed;
}

// 受保护集的网页播放数据。官网播放器对非公开集调用
// POST /api/video/protected/play-info（body: series_id/item_id/definition），
// 返回 play_info{main_url,backup_url,...}，direct mp4 可 Range 采样。
// definition 仅 360p/480p/720p 有效；720p 优先，逐级回退。
// 上游偶发瞬时抖动（5xx/网络错误/空地址）会吞掉整档清晰度；
// 对可重试错误在原清晰度上重试一次，403（未开播/无权限）不重试。
function _hg_protectRetryable(error) {
  const code = _hg_errorDetails(error).code;
  // 403(UNAVAILABLE)=未开播/无权限，语义确定不重试；其余传输层错误重试。
  return code === "UPSTREAM" || code === "NETWORK" || code === "TIMEOUT";
}

async function _hg_fetchProtectedOnce(seriesId, vid, definition) {
  const payload = await _hg_requestJSON("/api/video/protected/play-info", {
    series_id: seriesId,
    item_id: vid,
    definition
  });
  const playInfo = payload && payload.play_info;
  const url = playInfo && (_hg_str(playInfo.main_url).trim() || _hg_str(playInfo.backup_url).trim());
  if (!url) {
    _hg_throw("UPSTREAM", "红果受保护集播放数据缺少地址", { seriesId, vid, definition });
  }
  const media = {
    url,
    source: "web-protected",
    userAgent: _hg_webUserAgent,
    headers: { "Referer": _hg_baseURL + "/" }
  };
  const accessKey = _hg_str(playInfo.player_access_key).trim();
  // 宿主 LivePlaybackDecryption 契约：{method:"cenc", key:恰好32位hex}；
  // 缺 method 或 key 非 32hex 都会让 LiveQualityDetail 解码失败。
  // play-info 的 player_access_key 是非标准长度 base64，不能直接当 cenc key 下发；
  // 仅当上游给出合法 32hex 时才声明解密，否则按未加密流交付。
  if (/^[0-9a-fA-F]{32}$/.test(accessKey)) {
    media.decryption = { method: "cenc", key: accessKey.toLowerCase() };
  }
  return media;
}

// 官网受保护集的公开兜底流：fallback-play-info 返回未加密 mp4（avc1、无 senc/tenc），
// 宿主无需解密即可直接播；仅在 play-info 加密主路全部失败后使用。
async function _hg_fetchProtectedFallbackMedia(vid) {
  const payload = await _hg_requestJSON("/api/video/protected/fallback-play-info", { item_id: vid });
  const url = payload && _hg_str(payload.main_url).trim();
  if (!url) {
    _hg_throw("UPSTREAM", "红果公开兜底流缺少地址", { vid });
  }
  return {
    url,
    source: "web-public-fallback",
    userAgent: _hg_webUserAgent,
    headers: { "Referer": _hg_baseURL + "/" }
  };
}

async function _hg_fetchProtectedEpisodeMedia(seriesId, vid) {
  const definitions = ["720p", "480p", "360p"];
  let lastError;
  for (const definition of definitions) {
    try {
      return await _hg_fetchProtectedOnce(seriesId, vid, definition);
    } catch (error) {
      lastError = error;
      if (!_hg_protectRetryable(error)) continue;
      try {
        return await _hg_fetchProtectedOnce(seriesId, vid, definition);
      } catch (retryError) {
        lastError = retryError;
      }
    }
  }
  throw lastError || _hg_makeError("UPSTREAM", "红果受保护集播放数据不可用", { seriesId, vid });
}

async function _hg_fetchEpisodeMedia(seriesId, vid) {
  let appError;
  try {
    return await _hg_fetchAppEpisodeMedia(vid);
  } catch (error) { appError = error; }
  try {
    return await _hg_fetchWebEpisodeMedia(seriesId, vid);
  } catch (webError) {
    const webCode = _hg_errorDetails(webError).code;
    // 公开页 404（NOT_FOUND）或页面存在但无公开直链（UPSTREAM，protectedPlayback 集）
    // 都转受保护播放接口；真正的网络错误（NETWORK）直接上抛。
    if (webCode !== "NOT_FOUND" && webCode !== "UPSTREAM") throw webError;
    // 1.1.0：受保护集优先取官网公开兜底流（未加密 mp4，宿主零配置解码），
    // 失败再走加密 play-info（需宿主 cenc 解密链），把解密依赖降到最低。
    try {
      return await _hg_fetchProtectedFallbackMedia(vid);
    } catch (fallbackError) {
      try {
        return await _hg_fetchProtectedEpisodeMedia(seriesId, vid);
      } catch (protectedError) {
        // 全部失败时优先呈现“该集确实不可看”（NOT_FOUND），而非传输层噪音；
        // App 有真实网络/协议错误时仍保留它以便诊断。
        const appCode = _hg_errorDetails(appError).code;
        if (appCode && appCode !== "NOT_FOUND") throw appError;
        if (_hg_errorDetails(protectedError).code === "NOT_FOUND") throw protectedError;
        if (_hg_errorDetails(webError).code === "NOT_FOUND") throw webError;
        throw fallbackError.code ? fallbackError : protectedError;
      }
    }
  }
}

async function _hg_getPlayback(roomId, requestedVid) {
  const seriesId = _hg_requireSeriesId({ roomId });
  const detail = await _hg_fetchSeriesDetail(seriesId);
  if (detail.vids.length === 0) {
    _hg_throw("NOT_FOUND", "该剧没有返回剧集列表", { seriesId });
  }
  // 网页详情的 vid_list 可能只有前 5 集预览；优先用 App video_detail/v1
  // 获取完整分集目录。接口失败时才退回网页目录，不伪造集数或 VID。
  let appVids = [];
  try { appVids = await _hg_fetchAppEpisodeIds(seriesId, detail.vids[0]); }
  catch (_) { appVids = []; }
  const catalogVids = appVids.length
    ? appVids.concat(detail.vids.filter((vid) => !appVids.includes(vid)))
    : detail.vids;
  if (requestedVid && catalogVids.indexOf(requestedVid) < 0) {
    _hg_throw("NOT_FOUND", "所选集不属于该剧，请刷新剧集列表", { seriesId, vid: requestedVid });
  }
  // Resolve only the selected episode; remaining episodes refresh on selection.
  // Other episodes are catalog entries; the host refreshes them on selection.
  const initialVid = requestedVid || catalogVids[0];
  // 首集与后续选集共用同一条解析链，避免首集遗漏备用播放路径。
  let initialMedia;
  let appError;
  try { initialMedia = await _hg_fetchEpisodeMedia(seriesId, initialVid); }
  catch (error) { appError = error; }
  const usesApp = !!initialMedia && initialMedia.source === "app";
  const availableVids = appVids.length > 0
    ? catalogVids
    : (usesApp || detail.accessibleCount === null
      ? catalogVids
      : catalogVids.slice(0, detail.accessibleCount));
  if (availableVids.length === 0) {
    if (appError && _hg_errorDetails(appError).code !== "NOT_FOUND") throw appError;
    _hg_throw("NOT_FOUND", "该剧暂未向网页端开放播放，请在红果官方 App 中查看", { seriesId });
  }
  if (requestedVid && availableVids.indexOf(requestedVid) < 0) {
    if (appError && _hg_errorDetails(appError).code !== "NOT_FOUND") throw appError;
    _hg_throw("NOT_FOUND", "所选集未向网页端开放或不属于该剧，请在红果官方 App 中查看", { seriesId, vid: requestedVid });
  }

  if (!initialMedia) {
    try { initialMedia = await _hg_fetchWebEpisodeMedia(seriesId, initialVid); }
    catch (webError) {
      if (_hg_errorDetails(webError).code === "NOT_FOUND" && _hg_errorDetails(appError).code !== "NOT_FOUND") throw appError;
      throw webError;
    }
  }

  // 新版短剧宿主会保留空地址的 refreshOnSelect 条目，在点击及自动续集时
  // 先调用 refreshPlayback；不借用首集地址，不预取未选集的密钥。
  // 当前集也保留刷新声明，返回该集后再次选中时仍能获取新地址和密钥。
  const playable = availableVids.map((vid, index) => {
    const media = vid === initialVid ? initialMedia : null;
    const quality = {
      roomId: seriesId,
      title: `选集 · 第${index + 1}集`,
      qn: index + 1,
      url: media ? media.url : "",
      liveCodeType: "flv",
      liveType: _hg_liveType,
      requestContext: { vid, episode: String(index + 1) },
      playbackHints: { isLive: false, selectionBehavior: "refreshOnSelect" }
    };
    if (media) {
      quality.userAgent = media.userAgent;
      quality.headers = media.headers;
      if (media.decryption) quality.decryption = media.decryption;
    }
    return quality;
  });
  // getPlayback 的指定集请求也要让只取首项的宿主拿到指定集，刷新时不跳回首集。
  if (requestedVid) {
    const selectedIndex = playable.findIndex((quality) => quality.requestContext.vid === requestedVid);
    if (selectedIndex > 0) playable.unshift(playable.splice(selectedIndex, 1)[0]);
  }
  const label = appVids.length > 0
    ? `选集（共 ${playable.length} 集）`
    : (playable.length < catalogVids.length
      ? `选集（${usesApp ? "可播" : "网页可播"} ${playable.length}/${catalogVids.length} 集）`
      : "选集");
  return [{ cdn: label, qualitys: playable }];
}

function _hg_seriesIdFromText(text) {
  const input = _hg_str(text).trim();
  if (_hg_isNumericId(input)) return input;
  const patterns = [
    /hongguoduanju\.com\/player\/(\d+)\/(?:\d+)/i,
    /hongguoduanju\.com\/detail\?(?:[^#]*&)?series_id=(\d+)/i,
    /[?&]series_id=(\d+)/i
  ];
  for (const pattern of patterns) {
    const match = input.match(pattern);
    if (match && _hg_isNumericId(match[1])) return match[1];
  }
  return "";
}

function _hg_firstURL(text) {
  const match = String(text || "").match(/https?:\/\/[^\s|]+/i);
  return match ? String(match[0]).replace(/[),，。】]+$/g, "") : "";
}

async function _hg_searchSeries(keyword) {
  const response = await _hg_request(`${_hg_baseURL}/search/${encodeURIComponent(keyword)}`);
  const routerData = _hg_extractRouterData(response && response.bodyText, { keyword });
  const pageData = _hg_loaderPage(routerData, (value) => Array.isArray(value.searchList));
  if (!pageData || pageData.isSuccess === false) {
    return [];
  }
  const items = Array.isArray(pageData.searchList) ? pageData.searchList : [];
  return items
    .map((item) => _hg_dramaToRoom(item, _hg_defaultUserName))
    .filter((room) => !!room);
}

// ---- 首页 feed：多季聚合 ------------------------------------------------
// 红果没有季/部数据层级，同一部的各季是标题带"第N季/部"的独立剧集；
// 这里在首页把可识别的系列聚合成独立分区，宿主首页即可横向切换各季。

// 提取系列名：去掉尾部"第X季/部"与分隔标点，剩余部分作为系列 key。
function _hg_seriesKeyOf(title) {
  const text = _hg_str(title).trim();
  if (!text) return "";
  const stripped = text
    .replace(/[：:！!？?。\s]*第[一二三四五六七八九十百0-9]+[季部][^《》]*$/, "")
    .replace(/[：:！!？?。\s]+$/, "")
    .replace(/([^\d])([0-9]+)$/, "$1");
  return stripped.length >= 2 ? stripped : "";
}

function _hg_seasonIndexOf(title) {
  const match = _hg_str(title).match(/第([一二两三四五六七八九十百零〇0-9]+)[季部]/);
  if (!match) return 0;
  const numeral = match[1];
  if (/^\d+$/.test(numeral)) return Number(numeral);

  const digits = { 零: 0, 〇: 0, 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
  let section = 0;
  let number = 0;
  for (const ch of numeral) {
    if (ch in digits) {
      number = digits[ch];
    } else if (ch === "十") {
      section += (number || 1) * 10;
      number = 0;
    } else if (ch === "百") {
      section += (number || 1) * 100;
      number = 0;
    }
  }
  const total = section + number;
  return Number.isSafeInteger(total) && total > 0 ? total : 0;
}

// 首页分区：热门 + 可识别的多季系列（每系列一个分区，按季号排序）。
const _hg_homeFeedCache = { time: 0, value: null };
const _hg_homeFeedTTL = 30 * 60 * 1000;
const _hg_homeFeedSeriesLimit = 3;
const _hg_homeFeedSectionRooms = 10;

function _hg_homeSection(id, title, rooms, subtitle) {
  const seen = {};
  const items = [];
  for (const room of rooms || []) {
    if (!room || !room.roomId || seen[room.roomId]) continue;
    seen[room.roomId] = true;
    items.push({ id: String(room.roomId), room });
    if (items.length >= _hg_homeFeedSectionRooms) break;
  }
  if (!items.length) return null;
  const section = { id, kind: "rooms", title, personalized: false, items };
  if (subtitle) section.subtitle = String(subtitle).slice(0, 240);
  return section;
}

async function _hg_buildHomeFeed() {
  if (_hg_homeFeedCache.value && Date.now() - _hg_homeFeedCache.time < _hg_homeFeedTTL) {
    return _hg_homeFeedCache.value;
  }
  // 热门取真人剧前两页与漫剧/AI剧第一页；多季系列从这些房间识别，不额外发搜索请求。
  const pages = await Promise.all(
    _hg_categories.filter((category) => category.route !== "comic").flatMap((category) =>
      [1, category.route === "real-drama" ? 2 : 0].filter((page) => page >= 1).map((page) =>
        _hg_fetchCategoryPage(category.route, page).then(
          (result) => result.rooms.map((room) => Object.assign({}, room, { _category: category.title })),
          () => []
        )
      )
    )
  );
  const hot = [];
  {
    // 按分类轮询合并，热门区不单剧刷屏；顺序仍保持各分类内部的原序。
    const queues = pages.filter((page) => page.length);
    while (queues.length) {
      for (let index = queues.length - 1; index >= 0; index -= 1) {
        hot.push(queues[index].shift());
        if (!queues[index].length) queues.splice(index, 1);
      }
    }
  }

  const series = new Map();
  for (const room of hot) {
    const key = _hg_seriesKeyOf(room.roomTitle);
    if (!key) continue;
    const season = _hg_seasonIndexOf(room.roomTitle);
    if (!season) continue;
    let entry = series.get(key);
    if (!entry) {
      entry = { key, seasons: [] };
      series.set(key, entry);
    }
    if (!entry.seasons.some((item) => item.room.roomId === room.roomId)) {
      entry.seasons.push({ season, room });
    }
  }
  const multiSeason = [...series.values()]
    .filter((entry) => entry.seasons.length >= 2)
    .map((entry) => {
      entry.seasons.sort((a, b) => a.season - b.season);
      return entry;
    })
    .sort((a, b) => b.seasons.length - a.seasons.length)
    .slice(0, _hg_homeFeedSeriesLimit);

  const sections = [];
  const hotSection = _hg_homeSection("hot", "热门短剧", hot, "按热度排序的编辑推荐");
  if (hotSection) sections.push(hotSection);
  for (const entry of multiSeason) {
    const section = _hg_homeSection(
      "series-" + encodeURIComponent(entry.key).replace(/%/g, "").slice(0, 32),
      entry.key,
      entry.seasons.map((item) => item.room),
      `共 ${entry.seasons.length} 季：` + entry.seasons.map((item) => `S${item.season}`).join(" ")
    );
    if (section) sections.push(section);
  }
  if (sections.length === 0) {
    _hg_throw("UPSTREAM", "首页数据为空，请稍后重试", {});
  }
  const revisionSeed = sections
    .map((section) => section.id + ":" + section.items[0].id)
    .join("|");
  const value = {
    schemaVersion: 1,
    revision: String(revisionSeed).slice(0, 200) + ":" + Date.now(),
    generatedAt: new Date().toISOString(),
    ttlSeconds: Math.floor(_hg_homeFeedTTL / 1000),
    banners: [],
    sections
  };
  _hg_homeFeedCache.time = Date.now();
  _hg_homeFeedCache.value = value;
  return value;
}

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async getCategories() {
    return _hg_categories.map((category) => ({
      id: category.route,
      title: category.title,
      icon: "",
      biz: "",
      subList: [
        {
          id: category.route,
          parentId: category.route,
          title: "全部",
          icon: "",
          biz: ""
        }
      ].concat(category.subs.map((pair) => ({
        id: `${category.route}/${pair[0]}`,
        parentId: category.route,
        title: pair[1],
        icon: "",
        biz: ""
      })))
    }));
  },

  async getRooms(payload) {
    const route = _hg_str(payload && (payload.id || payload.categoryId)).trim();
    if (!_hg_isValidRoute(route)) {
      _hg_throw("INVALID_ARGS", "a valid 红果 category route is required", { field: "id" });
    }
    const page = Math.max(1, _hg_int(payload && payload.page, 1));
    const result = await _hg_fetchCategoryPage(route, page);
    return result.rooms;
  },

  async getPlayback(payload) {
    const context = payload && payload.requestContext && typeof payload.requestContext === "object"
      ? payload.requestContext
      : {};
    const requestedVid = _hg_str(payload && (payload.vid || context.vid)).trim();
    return await _hg_getPlayback(payload && payload.roomId, requestedVid);
  },

  async refreshPlayback(payload) {
    const seriesId = _hg_requireSeriesId(payload);
    const quality = payload && payload.quality && typeof payload.quality === "object" ? payload.quality : {};
    const qualityContext = quality.requestContext && typeof quality.requestContext === "object" ? quality.requestContext : {};
    const vid = _hg_str(qualityContext.vid).trim();
    if (!_hg_isNumericId(vid)) {
      _hg_throw("INVALID_ARGS", "refreshPlayback requires quality.requestContext.vid", { field: "vid" });
    }
    const media = await _hg_fetchEpisodeMedia(seriesId, vid);
    const prepared = Object.assign({}, quality, {
      url: media.url,
      userAgent: media.userAgent,
      headers: media.headers,
      playbackHints: Object.assign({}, quality.playbackHints, {
        isLive: false,
        selectionBehavior: "direct"
      })
    });
    // Refreshed URL and key are inseparable. A clear web fallback must not keep
    // a stale key from the previously selected encrypted media.
    delete prepared.decryption;
    if (media.decryption) prepared.decryption = media.decryption;
    return prepared;
  },

  async search(payload) {
    const keyword = _hg_str(payload && payload.keyword).trim();
    const page = Math.max(1, _hg_int(payload && payload.page, 1));
    if (!keyword) {
      _hg_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    }
    const page2 = page > 1;
    const seriesId = page2 ? "" : _hg_seriesIdFromText(keyword);
    if (seriesId) {
      return [await _hg_roomFromDetail(seriesId)];
    }
    if (page2) {
      return [];
    }
    const candidateURL = _hg_firstURL(keyword);
    if (candidateURL && /hongguoduanju\.com/i.test(candidateURL)) {
      const fromURL = _hg_seriesIdFromText(candidateURL);
      if (fromURL) return [await _hg_roomFromDetail(fromURL)];
    }
    return await _hg_searchSeries(keyword);
  },

  async getRoomDetail(payload) {
    return await _hg_roomFromDetail(_hg_requireSeriesId(payload));
  },

  async getLiveState() {
    return { liveState: "2" };
  },

  async getHomeFeed() {
    return await _hg_buildHomeFeed();
  },

  async resolveShare(payload) {
    const shareCode = _hg_str(payload && payload.shareCode).trim();
    if (!shareCode) {
      _hg_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    }
    const seriesId = _hg_seriesIdFromText(shareCode);
    if (!seriesId) {
      _hg_throw("NOT_FOUND", "分享内容中未找到红果剧集", { shareCode: shareCode.slice(0, 200) });
    }
    return await _hg_roomFromDetail(seriesId);
  }
};

async function _hg_roomFromDetail(seriesId) {
  const detail = await _hg_fetchSeriesDetail(seriesId);
  return {
    userName: _hg_defaultUserName,
    roomTitle: detail.name,
    roomCover: detail.cover,
    userHeadImg: detail.cover,
    liveType: _hg_liveType,
    liveState: "2",
    userId: detail.seriesId,
    roomId: detail.seriesId,
    liveWatchedCount: detail.episodeText
  };
}
